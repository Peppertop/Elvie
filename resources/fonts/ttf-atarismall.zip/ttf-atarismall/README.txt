These "Atari 8-bit" fonts are based on Thomas A. Fine's original
creation, converted to TrueType format by Gürkan Sengün.

Gürkan has given us permission to redistribute these fonts,
stating that "I am more than happy for anyone to use them 
as he wants to".

